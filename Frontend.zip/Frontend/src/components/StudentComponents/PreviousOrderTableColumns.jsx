export const PreviousOrderTableColumns = [
    //Order Id,Item Name,Quantity,Price,Date
    {
        Header:"Order Id",
        accessor: "orderId",
        Footer: "Order Id"
    },
    {
        Header:"Item Name",
        accessor: "itemName",
        Footer: "Item Name"
    },
    {
        Header:"Quantity",
        accessor: "quantity",
        Footer: "Quantity"
    },
    {
        Header:"Price",
        accessor: "price",
        Footer: "Price"
    },
    {
        Header:"Date",
        accessor: "date",
        Footer: "Date"
    },

]
