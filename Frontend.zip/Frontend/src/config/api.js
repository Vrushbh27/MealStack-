import api from '../api/axios';
export default api;
