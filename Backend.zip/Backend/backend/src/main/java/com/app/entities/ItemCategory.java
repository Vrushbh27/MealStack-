package com.app.entities;

public enum ItemCategory {
Breakfast, Lunch, Snacks, Dinner, Beverages;
}
