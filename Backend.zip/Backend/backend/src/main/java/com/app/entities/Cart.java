package com.app.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

import lombok.NoArgsConstructor;
import lombok.ToString;

@NoArgsConstructor
@ToString(exclude = "order")
@Entity
@Table(name = "carts")
public class Cart {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "cart_id", nullable = false, unique = true)
    private Long cartId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "order_id", nullable = false)
    private Order order;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "item_id", nullable = false)
    private ItemMaster item;

    @Column(name = "qty_ordered", nullable = false)
    private Integer qtyOrdered;

    @Column(name = "net_price", nullable = false)
    private Integer netPrice;

    // ===== GETTERS =====

    public Long getCartId() {
        return cartId;
    }

    public Order getOrder() {
        return order;
    }

    public ItemMaster getItem() {
        return item;
    }

    public Integer getQtyOrdered() {
        return qtyOrdered;
    }

    public Integer getNetPrice() {
        return netPrice;
    }

    // ===== SETTERS =====

    public void setCartId(Long cartId) {
        this.cartId = cartId;
    }

    public void setOrder(Order order) {
        this.order = order;
    }

    public void setItem(ItemMaster item) {
        this.item = item;
    }

    public void setQtyOrdered(Integer qtyOrdered) {
        this.qtyOrdered = qtyOrdered;
    }

    public void setNetPrice(Integer netPrice) {
        this.netPrice = netPrice;
    }
}
