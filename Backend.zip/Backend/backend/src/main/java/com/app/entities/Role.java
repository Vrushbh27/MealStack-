package com.app.entities;

public enum Role {
    STUDENT,
    ADMIN
}

